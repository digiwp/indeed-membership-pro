<?php
namespace Braintree\Exception;

use Braintree\Exception;

class InvalidSignature extends Exception
{
}
class_alias('Braintree\Exception\InvalidSignature', 'Braintree_Exception_InvalidSignature');
